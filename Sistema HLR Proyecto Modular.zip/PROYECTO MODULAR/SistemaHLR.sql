-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:8889
-- Tiempo de generación: 01-11-2023 a las 17:32:53
-- Versión del servidor: 5.7.34
-- Versión de PHP: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `SistemaHLR`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre_completo` varchar(255) NOT NULL,
  `matricula` int(50) NOT NULL,
  `correo` varchar(200) NOT NULL,
  `grado` varchar(50) NOT NULL,
  `ciclo` varchar(50) NOT NULL,
  `contraseña` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre_completo`, `matricula`, `correo`, `grado`, `ciclo`, `contraseña`) VALUES
(1, 'Dariadna Diaz ', 123456, '', '1 semestre', '2023-2024', '1234'),
(2, 'Emanuel Fuentes Ocegueda', 234567, '', 'Historico/Social', '2023-2024', '1234'),
(21, 'Monserrat Lopez Lopez', 345678, '', '3 secundaria', '2023-2024', '1234'),
(26, 'Isabel Montes Ramirez', 78901, '', '3 semestre', '2023-2024', '1234'),
(33, 'Charlotte Fuentes-Diaz', 2023001, '', '5 semestre', '2036-2037', 'Darymiamor'),
(36, 'Mario Eduardo Flores ', 457801, '', '2 secundaria', '2023-2024', '3456'),
(37, 'Judith Farías Sánchez', 236780, '', '4 semestre ', '2023-2024', '123'),
(38, 'Juan Manuel Ramirez Sanchez', 45682, '', '1 secundaria', '2023-2024', '123'),
(39, 'Paulina Garcia Gomez', 123, '', '3 semestre', '2023-2024', '123'),
(40, 'Juan Julio Alvarez Sanchez', 670570, '', 'Economico/Administrativo', '2023-2024', '2567368'),
(41, 'Zeus Arturo Diaz Flores ', 111, '', '3 semestre', '2023-2024', '111'),
(42, 'Henry Cavill', 364784, '', '4 semestre', '2023-2024', 'HENRYCALL'),
(43, 'DARIADNA YUNUEN DIAZ FLORES ', 1233, 'DARY@GMAIL.COM', 'INGENIERIA/ARQUITECTURA', '2023-2024', '123'),
(44, 'Yunuen Diaz Flores ', 222, 'daryflores0409@gmail.com', '2 semestre', '2023-2024', '111');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
