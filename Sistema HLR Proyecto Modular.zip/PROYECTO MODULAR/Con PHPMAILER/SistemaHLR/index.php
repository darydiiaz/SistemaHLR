<?php
     session_start();

     if(isset($_SESSION['usuario'])){
         header("location:assets/php/bienvenida.php");

     }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema del Colegio Hermanos López Rayón</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
  
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/php/PHPMailer/recovery_index.php">
    <link rel="stylesheet" href="assets/php/bienvenida.php">
    
    <link rel="stylesheet" href="assets/php/login_usuario_be.php">
    <link rel="stylesheet" href="assets/php/registrar_ususario_be.php">
    <link rel="stylesheet" href="assets/css/estilos_index.css">

    <link rel="stylesheet" href="assets/php/conexion_be.php">
    
    

</head>
<body>

        <main>

            <div class="contenedor__todo">
                <div class="caja__trasera">
                    <div class="caja__trasera-login">
                        <h3>¿Ya tienes una cuenta?</h3>
                        <p>Inicia sesión para entrar en la página</p>
                        <button id="btn__iniciar-sesion">Iniciar Sesión</button>
                    </div>
                    <div class="caja__trasera-register">
                        <h3>¿Aún no tienes una cuenta?</h3>
                        <p>Regístrate para que puedas iniciar sesión</p>
                        <button id="btn__registrarse">Regístrarse</button>
                    </div>
                </div>

                 <!--Formulario de Login y registro-->
            <div class="contenedor__login-register">
                <!--Login-->
                <form action="assets/php/login_usuario_be.php" method="POST"
                 class="formulario__login">
                    <h2>Iniciar Sesión</h2>
                    <input type="text" placeholder="Matrícula" name ="matricula">
                    <input type="password" placeholder="Contraseña" name ="contraseña">
                    <button>Entrar</button>
                       <nav>
                    <a href="recovery_index.php">¿Olvidaste tu contraseña?</a>
                        </nav>

                        
                </form>

    
        
      </div>

                <!--Register-->
                <form action="assets/php/registro_usuario_be.php" method="POST"
                 class="formulario__register">
                    <h2>Regístrarse</h2>
                    <input type="text" placeholder="Nombre completo" name="nombre_completo">
                    <input type="text" placeholder="Matrícula" name="matricula">
                    <input type="text" placeholder="Correo electronico" name="correo">
                    <input type="text" placeholder="Grado Estudiantil" name="grado">
                    <input type="text" placeholder="Ciclo escolar" name="ciclo">
                    <input type="password" placeholder="Contraseña" name="contraseña">
                    <button>Regístrarse</button>
                </form>
            </div>
        </div>

        </main>

        <script src="assets/js/script.js"></script>
</body>
</html>