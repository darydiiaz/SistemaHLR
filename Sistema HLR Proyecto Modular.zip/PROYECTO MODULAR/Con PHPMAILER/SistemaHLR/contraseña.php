
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>RECUPERAR CONTRASEÑA </title>
    </head>
    <body>
        
        <form action="contraseña.php" method="POST">
            <input type="text" name="correo" value="" placeholder="Ingresa tu correo" /> <br/>
            <input type="submit" value="Recordar contraseña" />
        </form>
        
        <?php
        
		try{
			if(isset($_POST['correo']) && !empty($_POST['correo'])){
                $pass = substr( md5(microtime()), 1, 10);
                $mail = $_POST['correo'];
                
                //Conexion con la base
                 $conexion = mysqli_connect("localhost","root",
                "root","SistemaHLR");

                // Check connection
                if ($conexion->connect_error) {
                    die("Connection failed: " . $conexion->connect_error);

                }

                $sql = "Update usuarios Set contraseña ='$contraseña' Where correo='$mail' ";

                if ($conexion->query($sql) === TRUE) {
                    echo "Usuario modificado correctamente ";
                } else {
                    echo "Error modificando: " . $conexion->error;
                }
                
                $to = $_POST['correo']; //"destinatario@email.com";
                $from = "From: " . "Sistema del Colegio Hermanos López Rayón" ;
                $subject = "Recordar contraseña";
                $message = "Buen día el Portal del Colegio Hermanos López Rayón
                            está en contacto contigo,daremos solución a tu problema. ";
                $message1 = "El sistema del Colegio Hermanos López Rayón 
                            le asigno la siguiente clave " . $contraseña;

                mail($to, $subject,$message, $message1, $from);
                echo 'Correo enviado satisfactoriamente a ' . $_POST['correo'];
            }
            else 
                echo 'Informacion incompleta';
		}
		catch (Exception $e) {
			echo 'Excepción capturada: ',  $e->getMessage(), "\n";
		}
            
        ?>
    </body>
</html>