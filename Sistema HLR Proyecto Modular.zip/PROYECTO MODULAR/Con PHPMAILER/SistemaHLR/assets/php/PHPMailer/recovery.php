<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
    use PHPMailer\PHPMailer\SMTP;
    
    
    require "Exception.php";
    require "PHPMailer.php";
    require "SMTP.php";
















    

/*
require_once('assets/php/conexion_be.php');
$correo = $_POST['correo'];
$query ="SELECT * FROM usuarios WHERE correo='$correo'  status = 1 ";

$result = $conexion->query($query);
$row = $result->fetch_assoc();
  


$oMail= new PHPMailer();
$oMail->isSMTP();
$oMail->Host="smtp.gmail.com";
$oMail->Port=587;
$oMail->SMTPSecure="tls";
$oMail->SMTPAuth=true;
$oMail->Username="diazdariadnadb@gmail.com";
$oMail->Password="ADMINDB2023";
$oMail->setFrom("diazdariadnadb@gmail.com","Pepito el que pica papas");
$oMail->addAddress("diazdariadnadb@gmail.com","Pepito2");
$oMail->Subject="Hola pepe el que pica";
$oMail->msgHTML("Hola soy un mensaje");
 
if(!$oMail->send())
  echo $oMail->ErrorInfo;  
*/
















/* 

if($result->num_rows > 0){
    $correo = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp-mail.outlook.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'Dariadna.Diaz@alumno.udg.mx';
        $mail->Password   = '18H04c93';
        $mail->Port       = 587;
    
        $mail->setFrom('Dariadna.Diaz@alumno.udg.mx', 'Sistema del Colegio Hermanos López Rayón');
        $mail->addAddress('daryflores0409@gmail.com', 'PRUEBA');
        $mail->isHTML(true);
        $mail->Subject = 'Recuperación de contraseña';
        $mail->Body    = 'Hola, este es un correo generado para solicitar tu recuperación de contraseña, por favor, visita la página de 
                <a href="localhost/SistemaHLR/recovery_index.php?id='.$row['id'].'">Recuperación de contraseña</a>';
     
        $correo->send();
        header("Location:recovery_index.php?message=ok");

} catch (Exception $e) {
         header("Location:recovery_index.php?message=error");
  }
  
  }else{
    
    header("Location:recovery_index.php?message=not_found");
  }
  */

?>