<?php 

   session_start();

   

   if(!isset($_SESSION['usuario'])){

      echo '
          <script>
             alert("POR FAVOR DEBES INICIAR SESIÓN");
             location.assign("http://localhost:8888/SistemaHLR/");
          </script>   
      ';
    
         session_destroy();
         die();
         
   }
 
?>
    <?php 
      header('Content-Type: text/html; charset=UTF-8');  
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal Hermanos López Rayón</title>

               <!--  CSS -->
    <link rel="stylesheet" href="../css/scanner.css">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/generator.css">
    <link rel="stylesheet" href="../css/stylesQR.css">
    <link rel="stylesheet" href="conexion_be.php">
    <link rel="shortcut icon" href="qryt.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
   <!-- FONT AWESOME -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    
</head> 
<body>

     <header>
      
          <div class="escudo">
            <img src="../images/HLR.jpg" alt="escudo del colegio">
         </div>

          <nav>
         <!-- <a href="QR.html">Scan QR</a>-->
          <a href="cerrar_sesion.php">Cerrar Sesión</a>

          </nav>

     </header>


  <!-- PARA PODER TRAER LOS DATOS DE LA BASE DE DATOS  -->

     <?php
     
     include 'conexion_be.php';
     header("Content-Type: text/html;charset=utf-8");

     if (!isset($_SESSION['usuario'])) {
      // Redireccionar a la página de inicio de sesión si el usuario no ha iniciado sesión
      header("location: index.php");
      exit();
      }
     $iduser = $_SESSION['usuario'];
     $sql="SELECT matricula,nombre_completo,correo,grado,ciclo FROM usuarios
                 WHERE matricula = '$iduser' ";
     $resultado = $conexion->query($sql);
     $row = $resultado->fetch_assoc();

    ?>

   <!-- TITULO -->
         <h1>Bienvenido a tu credencial digital</h1>

   
    <div class="container">
       <!-- NAV -->
         <nav>
           <button class="nav-gene active">GENERADOR</button>
           <button class="nav-scan">ESCÁNER</button>

         </nav>

        <!--GENERADOR -->
           <div class="generator" >
           <h1> Generador de código QR </h1>
           <!-- <p>Introduce tu matrícula,nombre completo y grado estudiantil </p> -->
          
           <?php echo utf8_decode(
         'Matricula: '.$row["matricula"]."  ".
         ', nombre completo:  '.$row['nombre_completo']."  ".
         ', correo electronico:  '.$row["correo"]."  ".
         ', grado estudiantil: '.$row["grado"]."  ".
         ', ciclo escolar: '.$row["ciclo"].'.');
      
            ?>

           <div class="generator-form">
              
               <input type="text"  placeholder="Texto por defecto" 
                    value= " <?php echo utf8_decode(
                                $row["matricula"]."  ".  $row['nombre_completo']."  "
                                .$row["grado"]);
                             ?>" readonly onmousedown="return false;" > 
               <button>Generar el código QR</button>
           </div>

           <div class="generator-img">
              <img src="qryt.png" alt="qr-code">
              
           </div>

             <div class="generator-btn">
                 <button class="btn-link">Descargar <i class="fa-solid fa-download fa-beat"> </i>></i></button>

             </div>

             <div class="generator-img-cred">
              <img src="qryt.png" alt="qr-code-cred">
           </div>

             <div class="img-cred">
              <img src="cred.jpg" alt="code-cred">
           </div>

             <div class="generator-btn-cred">
                 <button class="btn-link">Descargar <i class="fa-solid fa-download fa-beat"> </i>></i></button>

             </div>

    </div> <!-- div del generador -->
        


        <!-- SCANNER-->
        <div class="scanner" style="display: none;" >
         <h1> Escáner de código qr o lector de código qr
             <i class="fa-solid fa-camera"></i> 
             <i class="fa-solid fa-circle-stop"></i>     
         </h1>
            
         <form class="scanner-form">
            <input type="file" accept="image/*" hidden>

            <img src="qryt.png" alt="qr-code">
            <video></video>

                <div class="content">
                   <i class="fa-solid fa-cloud-arrow-up fa-beat"></i>
                  <p>Subir QR al escáner</p>
         
                </div>

         </form>
              <div class="scanner-details">
               <textarea disabled></textarea>

                 <div class="btn">
                    <button class="close">Cerrar</button>
                    <button class="copy">Copiar</button>
                  </div>

               </div><!-- div del scanner-details-->

        </div>  <!-- div del scanner-->


    </div> <!-- div del container-->
 
    
    
          <!-- JavaScript -->
          <script src="js/main.js"> </script>
          <script src="js/generator.js"> </script>
          <script src="js/scanner.js"> </script>
          <script src="instascan.min.js"> </script>
    
   
    
</body>
</html>