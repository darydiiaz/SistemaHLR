<?php
    
    session_start();
    include 'conexion_be.php';


    $matricula = $_POST['matricula'];
    $contraseña = $_POST['contraseña'];
    

    $validar_login = mysqli_query($conexion,"SELECT * FROM usuarios
    WHERE matricula='$matricula' and contraseña='$contraseña' " );

    if(mysqli_num_rows($validar_login) > 0){
        $_SESSION['usuario']= $matricula;
        header("location: bienvenida.php");
        exit;
    }else{
        echo'
        <script>
            alert("USUARIO NO EXISTE,POR FAVOR REVISE LOS DATOS INTRODUCIDOS ");
            location.assign("http://localhost:8888/SistemaHLR/");
        </script>
        ' ;
        exit;
    }




?>