<?php 

include 'conexion_be.php';

$nombre_completo = $_POST['nombre_completo'];
$matricula =$_POST['matricula'];
$correo =$_POST['correo'];
$grado =$_POST['grado'];
$ciclo =$_POST['ciclo'];
$contraseña =$_POST['contraseña'];
// ¿ENCRIPTAR LA CONTRASEÑA?  $contraseña = hash('sha512', $contraseña);


$query = "INSERT INTO usuarios(nombre_completo,matricula,correo,grado,ciclo,contraseña)
          VALUES('$nombre_completo','$matricula','$correo','$grado','$ciclo','$contraseña')" ;


//VERIFICAR QUE LA MATRÍCULA NO SE REPITA EN LA BASE DE DATOS 

$verificar_mat = mysqli_query($conexion,"SELECT * FROM usuarios WHERE matricula='$matricula' " );

if(mysqli_num_rows($verificar_mat) > 0 ){
    echo '
    <script>
       alert("¡Está matrícula ya está registrada!");
       location.assign("http://localhost:8888/SistemaHLR/");
       </script>
    
    ';
    exit();
   
}

//VERIFICAR QUE EL NOMBRE NO SE REPITA EN LA BASE DE DATOS 

$verificar_nom = mysqli_query($conexion,"SELECT * FROM usuarios WHERE nombre_completo='$nombre_completo' " );

if(mysqli_num_rows($verificar_nom) > 0 ){
    echo '
    <script>
       alert("¡Este nombre ya está registrado!");
       location.assign("http://localhost:8888/SistemaHLR/");
       </script>
    
    ';
    exit();
}



$ejecutar = mysqli_query($conexion,$query);

if($ejecutar){
    echo'
       <script>
          alert("Usuario almacenado exitosamente");
          location.assign("http://localhost:8888/SistemaHLR/");

          </script>

    ';
    
        }else{

       echo'
            <script>
              alert("Intentalo de nuevo,usuario no almacenado");
              location.assign("http://localhost:8888/SistemaHLR/");

          </script>
';
        }
        mysqli_close($conexion);
?>