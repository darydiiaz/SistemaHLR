



<?php
     session_start();

     if(isset($_SESSION['usuario'])){
         header("location: assets/php/bienvenida.php");

     }
   


?>




<!DOCTYPE html>
<html lang="en">
  
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RECUPERAR CONTRASEÑA</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link rel="stylesheet" href="conexion_be.php">
    <link rel="stylesheet" href="index.php">
    <link rel="stylesheet" href="assets/php/PHPMailer/recovery.php">
    
    <link rel="stylesheet" href="assets/php/login_usuario_be.php">
    <link rel="stylesheet" href="assets/php/cerrar_sesion.php">
    <link rel="stylesheet" href="assets/css/estilos2.css">
    <link rel="stylesheet" href="assets/css/styles.css">
 
    
</head>

<body>

       

<body class="text-center">
    
    <main class="form-signin w-100 m-auto">
      <form action="assets/php/PHPMailer/recovery.php" method="POST">
        <h1>RECUPERAR CONTRASEÑA</h1>
        <h2 class="h5 mb-3 fw-normal">En breve se pondran en contacto el Sistema del Colegio Hermanos López Rayón</h2>
        <div class="form-floating my-3">
          <input type="correo" class="form-control" id="floatingInput" placeholder="name@example.com" name="correo">
          <label for="floatingInput">Correo electrónico</label>
        </div>
        <button class="w-100 btn btn-lg btn-primary" type="submit">Recuperar contraseña</button>
      </form>
    </main>
    




 <!--Register
            <div class="contenedor__todo">
                <div class="caja__trasera">
                    <div class="caja__trasera-login">
                        <h3>Recuperar tu contraseña </h3>
                        
                        <form action="contraseña.php" method="POST">
                        <input type="text" name="correo" value="" placeholder="Ingresa tu correo" /> <br/>
                        
                        <button id="btn__iniciar-sesion">Recordar contraseña</button>
                        </form>
                    </div>
                    
                </div>        
                       
            </div>
-->
<!--Register
<div class="contenedor__todo">
               
                      
                        
        <div class="contenedor__login-register">
               

               <form action="assets/php/login_usuario_be.php" method="POST"
                class="formulario__login">
                   <h2>Recuperación de contraseña </h2>
                   <input type="text" placeholder="Correo electronico" name="correo">
                   <button id="btn__iniciar-sesion">Enviar correo</button>

               </form>

                        
         </div>
</div>
          
-->
<!--Register
                 <div class="contenedor__login-register">
               
                <form action="assets/php/login_usuario_be.php" method="POST"
                 class="formulario__login">
                    <h2>Recuperación de contraseña </h2>
                    <input type="text" placeholder="Correo electronico" name="correo">
                    <button id="btn__iniciar-sesion">Enviar correo</button>

                </form>
             
     -->





     

</body>
</html>